﻿using System;
using Gtk;
using Cairo;
using Clock;


public partial class MainWindow : Gtk.Window
{
    ClockManage clock;

    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        Build();

        ClockArea.ModifyBg(StateType.Normal, new Gdk.Color(0, 0, 0));
        clock = new ClockManage();

        ClockStart();
    }

    void    ClockStart()
    {
        GLib.Timeout.Add(100, new GLib.TimeoutHandler(Update));
    }

    bool Update()
    {
        ClockArea.GdkWindow.Clear();

        DigitalTime.Text = DateTime.Now.ToString("T");
        clock.DrawRing(ClockArea.GdkWindow);
        clock.HourLine(ClockArea.GdkWindow);
        clock.MinuteLine(ClockArea.GdkWindow);
        clock.SecondLine(ClockArea.GdkWindow);

        return (true);
    }
    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }
}
