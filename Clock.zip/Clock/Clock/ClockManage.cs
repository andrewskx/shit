﻿using System;
using Cairo;

namespace Clock
{
    public class ClockManage
    {
        public Antialias universalAntiA = Antialias.Default;

        public void DrawRing(Gdk.Window ClockArea)
        {
            int     clockAmount;
            double  rotateAmount;

            clockAmount = 0;
            rotateAmount = 0;

            //Cairo.Context cr = Gdk.CairoHelper.Create(ClockArea);
            //cr.SetSourceColor(new Cairo.Color(0, 0, 0));
            //cr.Arc(110, 110, 100, 0, Math.PI * 2);
            //cr.Stroke();

            while (clockAmount < 12)
            {
                Cairo.Context cr = Gdk.CairoHelper.Create(ClockArea);

                PointD point1, point2;

                point1 = new PointD(85.0, 0);
                point2 = new PointD(95.0, 0);
               
                cr.SetSourceColor(new Cairo.Color(1, 1, 1));
                cr.Arc(110, 110, 100, 0, Math.PI * 2);
                cr.Stroke();
                cr.Antialias = universalAntiA;
                cr.LineCap = LineCap.Round;
                cr.Translate(110, 110);
                cr.Rotate(rotateAmount);
                cr.LineWidth = 4;
                cr.MoveTo(point1);
                cr.LineTo(point2);
                cr.SetSourceColor(new Cairo.Color(0.95, 0.95, 0.95));
                cr.Stroke();

                cr.GetTarget().Dispose();
                cr.Dispose();
                rotateAmount += (Math.PI * 2)  / 12;
                clockAmount++;
            }
        }

        public void MinuteLine(Gdk.Window ClockArea)
        {
            Cairo.Context cr = Gdk.CairoHelper.Create(ClockArea);

            PointD point1, point2;

            point1 = new PointD(0, 0);
            point2 = new PointD(0, -80);

            cr.Antialias = universalAntiA;
            cr.LineCap = LineCap.Round;
            cr.Translate(110, 110);
            cr.Rotate(CalculateMinuteAngle());
            cr.LineWidth = 5;
            cr.MoveTo(point1);
            cr.LineTo(point2);
            cr.SetSourceColor(new Cairo.Color(255, 255, 255));
            cr.Stroke();

            cr.GetTarget().Dispose();
            cr.Dispose();
        }

        double CalculateMinuteAngle()
        {
            double radian;

            radian = 0.01745 * 6 * DateTime.Now.Minute;

            return (radian);
        }

        public void HourLine(Gdk.Window ClockArea)
        {
                Cairo.Context cr = Gdk.CairoHelper.Create(ClockArea);

                PointD point1, point2;

                point1 = new PointD(0, 0);
                point2 = new PointD(0, -50);

                cr.Antialias = universalAntiA;
                cr.LineCap = LineCap.Round;
                cr.Translate(110, 110);
                cr.Rotate(CalculateHourAngle());
                cr.LineWidth = 3;
                cr.MoveTo(point1);
                cr.LineTo(point2);
                cr.SetSourceColor(new Cairo.Color(255, 0, 0));
                cr.Stroke();

                cr.GetTarget().Dispose();
                cr.Dispose();
        }

        public void SecondLine(Gdk.Window ClockArea)
        {
            Cairo.Context cr = Gdk.CairoHelper.Create(ClockArea);

            PointD point1, point2;

            point1 = new PointD(0, 0);
            point2 = new PointD(0, -80);

            cr.Antialias = universalAntiA;
            cr.LineCap = LineCap.Round;
            cr.Translate(110, 110);
            cr.Rotate(CalculateSecondAngle());
            cr.LineWidth = 3;
            cr.MoveTo(point1);
            cr.LineTo(point2);
            cr.SetSourceColor(new Cairo.Color(255, 255, 255));
            cr.Stroke();

            cr.GetTarget().Dispose();
            cr.Dispose();
        }


        double CalculateSecondAngle()
        {
            double radian;

            radian = 0.01745 * 6 * DateTime.Now.Second;

            return (radian);
        }

        double CalculateHourAngle()
        {
            double  radian;
            int     minutes;

            radian = Math.PI * 2;
            if (DateTime.Now.Hour > 12)
            {
                minutes = (DateTime.Now.Hour - 12) * 60 + (DateTime.Now.Minute);
            }
            else
                minutes = DateTime.Now.Hour * 60 + (DateTime.Now.Minute);

            radian = radian * (0.0013888 * (double)minutes);

            return (radian);
        }
    }
}
