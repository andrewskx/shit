﻿using System;
namespace Clock
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
