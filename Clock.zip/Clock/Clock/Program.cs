﻿using System;
using Gtk;
using Cairo;

namespace Clock
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Application.Init();
            MainWindow win = new MainWindow();
            win.Title = "PPE_6_BOSCANEAN_TI-162";
            win.Show();
            Application.Run();
        }
    }
}
