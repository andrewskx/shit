﻿using System;
using Gtk;
using Cairo;

public partial class MainWindow : Gtk.Window
{
    int width, height;
    double angle;
    Cairo.PointD p1, p2, p3, p4;
    Cairo.PointD aux1, aux2, aux3, aux4;

    [GLib.ConnectBefore]
    void Handle_KeyPressEvent(object o, KeyPressEventArgs args)
    {
        if (args.Event.KeyValue == (uint)Gdk.Key.Up && height - 10 >= 0)
            height -= 10;
        else if (args.Event.KeyValue == (uint)Gdk.Key.Down && height + 50 <= Allocation.Height)
            height += 10;
        else if (args.Event.KeyValue == (uint)Gdk.Key.Right && width + 10 <= Allocation.Width)
            width += 10;
        else if (args.Event.KeyValue == (uint)Gdk.Key.Left && width - 10 >= 0)
            width -= 10;
        else if (args.Event.KeyValue == (uint)Gdk.Key.r)
            angle += (7 * 0.01745);
        else if (args.Event.KeyValue == (uint)Gdk.Key.l)
            angle -= (7 * 0.01745);
        else if (args.Event.KeyValue == (uint)Gdk.Key.equal)
        {
            p1.X *= 1.1;
            p1.Y *= 1.1;
            p2.X *= 1.1;
            p2.Y *= 1.1;
            p3.X *= 1.1;
            p3.Y *= 1.1;
            p4.X *= 1.1;
            p4.Y *= 1.1;
        }
        else if (args.Event.KeyValue == (uint)Gdk.Key.minus)
        {
            p1.X /= 1.1;
            p1.Y /= 1.1;
            p2.X /= 1.1;
            p2.Y /= 1.1;
            p3.X /= 1.1;
            p3.Y /= 1.1;
            p4.X /= 1.1;
            p4.Y /= 1.1;
        }
        else
            Console.WriteLine("key pressed -> " + args.Event.Key);
        something();
    }
    DrawingArea darea;
    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        
        SetDefaultSize(500, 500);
        SetPosition(WindowPosition.Center);
        DeleteEvent += delegate { Application.Quit(); };
        KeyPressEvent += Handle_KeyPressEvent;

        darea = new DrawingArea();
        darea.ExposeEvent += delegate { something();  };

        Add(darea);
        darea.ModifyBg(StateType.Normal, new Gdk.Color(155, 0, 155));
        ShowAll();
        Build();
        width = height = 250;
        angle = 0;
        p1 = new PointD(-25, -25);
        p2 = new PointD(25, -25);
        p3 = new PointD(25, 25);
        p4 = new PointD(-25, 25);
        aux1 = new PointD(0, 0);
        aux2 = new PointD(0, 0);
        aux3 = new PointD(0, 0);
        aux4 = new PointD(0, 0);
    }

    void    rotate()
    {
        aux1.X = (Math.Cos(angle) * p1.X - Math.Sin(angle) * p1.Y + width);
        aux1.Y = (Math.Sin(angle) * p1.X + Math.Cos(angle) * p1.Y + height);
        aux2.X = (Math.Cos(angle) * p2.X - Math.Sin(angle) * p2.Y + width);
        aux2.Y = (Math.Sin(angle) * p2.X + Math.Cos(angle) * p2.Y + height);
        aux3.X = (Math.Cos(angle) * p3.X - Math.Sin(angle) * p3.Y + width);
        aux3.Y = (Math.Sin(angle) * p3.X + Math.Cos(angle) * p3.Y + height);
        aux4.X = (Math.Cos(angle) * p4.X - Math.Sin(angle) * p4.Y + width);
        aux4.Y = (Math.Sin(angle) * p4.X + Math.Cos(angle) * p4.Y + height);
    }
    void    something()
    {
        Cairo.Context cr = Gdk.CairoHelper.Create(darea.GdkWindow);
        darea.GdkWindow.Clear();

        cr.LineWidth = 9;
        cr.SetSourceRGB(1, 1, 1);

        //int width, height;
        //width = Allocation.Width;
        //height = Allocation.Height;

        // cr.Rotate(angle);
        // cr.Translate(width, height);
        // cr.Arc(width, height, 50, 0, Math.PI);
        rotate();
        cr.MoveTo(aux1);
        cr.LineTo(aux2);
        cr.LineTo(aux3);
        cr.LineTo(aux4);
        cr.ClosePath();
        cr.StrokePreserve();

        cr.SetSourceRGB(0.3, 0.4, 0.6);
        cr.Fill();
        ((IDisposable)cr).Dispose();
    }

    [GLib.ConnectBefore]
    protected void Motion(object o, MotionNotifyEventArgs args)
    {
        Application.Quit();
        args.RetVal = true; 
    }
}