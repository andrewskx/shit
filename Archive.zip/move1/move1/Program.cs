﻿using System;
using Gtk;

namespace move1
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Application.Init();
            MainWindow win = new MainWindow();
            win.Title = "TI_162_PPE";
            win.Show();
            Application.Run();
        }
    }
}
