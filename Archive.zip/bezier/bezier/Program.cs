﻿using System;
using Gtk;

namespace bezier
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Application.Init();
            MainWindow win = new MainWindow();
            win.Title = "Bezier_Curve_TI_162";
            win.Show();
            Application.Run();
        }
    }
}
