﻿using System;
using Gtk;
using Cairo;

public partial class MainWindow : Gtk.Window
{
    DrawingArea bezierArea;
    Cairo.PointD ctrl1, ctrl2, ctrl3;
    Cairo.PointD mine1, mine2, mine3;
    Cairo.PointD last, offset1, offset2, offset3, circle;
    bool isButtonPressed, staticCoords;

    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        bezierArea = new DrawingArea();
        SetDefaultSize(800, 800);
        SetPosition(WindowPosition.Center);
        SetSizeRequest(300, 500);
        Add(bezierArea);
        bezierArea.ModifyBg(StateType.Normal, new Gdk.Color(255, 0, 255));
        bezierArea.AddEvents(
                (int)Gdk.EventMask.PointerMotionMask
                | (int)Gdk.EventMask.ButtonPressMask
                | (int)Gdk.EventMask.ButtonReleaseMask);
        bezierArea.ExposeEvent += BezierArea_ExposeEvent;
        bezierArea.ButtonPressEvent += BezierArea_ButtonPressEvent;
        bezierArea.ButtonReleaseEvent += BezierArea_ButtonReleaseEvent;
        bezierArea.MotionNotifyEvent += BezierArea_MotionNotifyEvent;
        ShowAll();
        Build();
        ctrl1 = ctrl2 = ctrl3 = mine1
            = mine2 = mine3 = last = new PointD(0, 0);
        offset1 = offset2 = offset3 = new PointD(0, 280);
        circle = new PointD(200, 200);
        isButtonPressed = false;
        staticCoords = true;
    }

    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }

    void BezierArea_ButtonPressEvent(object o, ButtonPressEventArgs args)
    {
        if (args.Event.Button == 1)
        {
            isButtonPressed = true;
            last.X = args.Event.X;
            last.Y = args.Event.Y;
        }
    }

    void BezierArea_ButtonReleaseEvent(object o, ButtonReleaseEventArgs args)
    {
        if (args.Event.Button == 1)
            isButtonPressed = false;
    }

    //[GLib.ConnectBefore]
    void BezierArea_MotionNotifyEvent(object o, MotionNotifyEventArgs args)
    {
        if (isButtonPressed)
        {
            if (last.X >= mine1.X - 5 && last.X < mine1.X + 5
               && last.Y >= mine1.Y - 5 && last.Y < mine1.Y + 5)
            {
                staticCoords = false;
                offset1.X += (args.Event.X - last.X);
                offset1.Y += (args.Event.Y - last.Y);
               // Console.WriteLine("dx1 = " + (args.Event.X - last.X) + " dy = " + (args.Event.Y - last.Y));

                last.X = args.Event.X;
                last.Y = args.Event.Y;
                draw();

            }
            else if (last.X >= mine2.X - 5 && last.X < mine2.X + 5
               && last.Y >= mine2.Y - 5 && last.Y < mine2.Y + 5)
            {
                staticCoords = false;
                offset2.X += (args.Event.X - last.X);
                offset2.Y += (args.Event.Y - last.Y);
                //Console.WriteLine("dx2 = " + (args.Event.X - last.X) + " dy = " + (args.Event.Y - last.Y));

                last.X = args.Event.X;
                last.Y = args.Event.Y;
                draw();

            }
            else if (last.X >= mine3.X - 5 && last.X < mine3.X + 5
              && last.Y >= mine3.Y - 5 && last.Y < mine3.Y + 5)
            {
                staticCoords = false;
                offset3.X += (args.Event.X - last.X);
                offset3.Y += (args.Event.Y - last.Y);
                //Console.WriteLine("dx3 = " + (args.Event.X - last.X) + " dy = " + (args.Event.Y - last.Y));

                last.X = args.Event.X;
                last.Y = args.Event.Y;
                draw();

            }
            else if (last.X >= circle.X - 30 && last.X < circle.X + 30 
                     && last.Y >= circle.Y - 30 && last.Y < circle.Y + 30)
            {
                circle.X += (args.Event.X - last.X);
                circle.Y += (args.Event.Y - last.Y);
                last.X = args.Event.X;
                last.Y = args.Event.Y;
                draw();
            }
         //   draw();
        }

    }

    void draw()
    {
        Cairo.Context cr = Gdk.CairoHelper.Create(bezierArea.GdkWindow);
        bezierArea.GdkWindow.Clear();
        int width, height;
        double t, x, y;

        width = Allocation.Width;
        height = Allocation.Height;

        //ctrl1.X = width / 4;
        //ctrl1.Y = height / 4;
        //ctrl2.X = width / 2;
        //ctrl2.Y = height / 12;
        //ctrl3.X = width / 2;
        //ctrl3.Y = height / 4;

        //if (staticCoords)
        //{
        //    mine1.X = width / 4;
        //    mine1.Y = height / 4 + 280;
        //    mine2.X = width / 2;
        //    mine2.Y = height / 12 + 280;
        //    mine3.X = width / 2;
        //    mine3.Y = height / 4 + 280;
        //}
        //else
        //{
            mine1.X = width / 4 + offset1.X;
            mine1.Y = height / 4 + offset1.Y;
            mine2.X = width / 2 + offset2.X;
            mine2.Y = height / 12 + offset2.Y;
            mine3.X = width / 2 + offset3.X;
            mine3.Y = height / 4 + offset3.Y;

            ctrl1.X = mine1.X;
            ctrl1.Y = mine1.Y - 280;
            ctrl2.X = mine2.X;
            ctrl2.Y = mine2.Y - 280;
            ctrl3.X = mine3.X;
            ctrl3.Y = mine3.Y - 280;
      //  }
        cr.SetSourceRGB(1, 1, 1);
        cr.LineWidth = 2;
        cr.MoveTo(ctrl1);
        cr.CurveTo(ctrl1, ctrl2, ctrl3);
        cr.Stroke();

        cr.SetSourceRGB(0, 0, 0);
        cr.MoveTo(mine1);
        x = y = t = 0;
        while (t < 1)
        {
            x = Math.Pow((1 - t), 2) * mine1.X + 2 * (1 - t) * t * mine2.X + t * t * mine3.X;
            y = Math.Pow((1 - t), 2) * mine1.Y + 2 * (1 - t) * t * mine2.Y + t * t * mine3.Y;
            cr.LineTo(x, y);
            t += 0.010;
        }
        cr.LineWidth = 2;
        cr.Stroke();

        cr.SetSourceRGB(1, 1, 1);
        cr.Arc(mine1.X, mine1.Y, 5, 0, 2 * Math.PI);
        cr.Fill();
        cr.Stroke();
        cr.Arc(mine2.X, mine2.Y, 5, 0, 2 * Math.PI);
        cr.Fill();
        cr.Stroke();
        cr.Arc(mine3.X, mine3.Y, 5, 0, 2 * Math.PI);
        cr.Fill();
        cr.Stroke();
        cr.SetSourceRGB(1, 0.7, 1);
        cr.Arc(circle.X, circle.Y, 30, 0, 2 * Math.PI);
        cr.Fill();
        cr.StrokePreserve();
        ((IDisposable)cr).Dispose();
    }

    void BezierArea_ExposeEvent(object o, ExposeEventArgs args)
    {
        draw();
    }
}
