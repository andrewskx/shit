﻿using System;
using Gtk;
using Pango;

namespace lab1_PPE
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Label label1;
            //string str = "Laborator 1 PPE__C#, Boscanean Andrian, TI-162";

            Application.Init();
            MainWindow win = new MainWindow();
            //label1 = new Label(str);
           // win.Add(label1);
           //// label1.SetAlignment(0.5f, 0f);
            //win.ModifyBg(StateType.Normal, new Gdk.Color(255, 0, 20));
            //label1.ModifyText(StateType.Normal, new Gdk.Color(255, 0, 255));
            //win.SetDefaultSize(500, 500);
            win.ShowAll();
            Application.Run();
        }
    }
}