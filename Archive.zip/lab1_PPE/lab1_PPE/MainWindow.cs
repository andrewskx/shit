﻿using System;
using Gtk;

public partial class MainWindow : Gtk.Window
{
    Label name;
    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        name = new Label("Laborator 1 PPE Nicula Sandu TI-162");
        SetDefaultSize(340, 300);
        SetPosition(WindowPosition.Center);
        Add(name);
        name.SetSizeRequest(340, 200);
        ModifyBg(StateType.Normal, new Gdk.Color(255, 255, 255));
        ShowAll();
        Build();
    }

    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }
}
